---
lab:
    title: 'Create a Regression Model with Azure Machine Learning designer'
---

## Instructions
In this lab we will look at how to create regression models using Azure Machine Learning designer.

1.	Go to the Microsoft Learn module at https://docs.microsoft.com/learn/modules/create-regression-model-azure-machine-learning-designer/
